 # @Lia
 # Module for data validation

import re

def validate_invoice_data(data):
    # Example rules
    is_valid = True
    errors = []
    # My date format is Month(String) Date(float) Year(float), this regex is formatted for all regex patterns like:
    # YYYY-MM-DD (e.g., 2024-01-01)
    # MM/DD/YYYY (e.g., 01/25/2024)
    # MM/DD/YY (e.g., 01/25/24)
    # Month DD, YYYY (e.g., January 25, 2024)
    date_pattern = r'(\d{4}-\d{2}-\d{2}|\d{2}/\d{2}/\d{4}|\d{2}/\d{2}/\d{2}|\w{3,9} \d{1,2}, \d{4})'
    if not re.match(date_pattern, data.get("date", "")):
        is_valid = False
        errors.append("Invalid date format")
        
    if not isinstance(data.get("amount"), (float, int)):
        is_valid = False
        errors.append("Invalid amount")

    return is_valid, errors