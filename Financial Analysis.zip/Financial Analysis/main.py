# @Lia
# Main script

import os
import re
import pandas as pd
from ocr_module import extract_text
from data_validation import validate_invoice_data

def parse_invoice_text(ocr_text):
   # Extract Invoice Number (but not including the "Invoice:")
    invoice_id = re.search(r'#\s*(\d+)', ocr_text)
    # Extracting Date (in format: e.g. Jan 1, 2000)
    date = re.search(r'\b([A-Za-z]{3,9} \d{1,2}, \d{4})\b', ocr_text) # Note: If your date comes in an alternate format, try r'Date:\s*([\d/,-\w]+)', ocr_text)  # - this adjusts for flexible date formats
    # Extract Amount (also known as "Balance Due")
    amount = re.search(r'Balance Due:\s*(US?\$[\d,]+\.\d{2})', ocr_text)
    # Extract name (e.g., Bill To: John Doe)
    name = re.search(r'(?:Bill To:|Customer:)\s*([A-Za-z\s]+)', ocr_text)

    return {
        "invoice_id": invoice_id.group(1) if invoice_id else "Unknown",
        "date": date.group(1) if date else "Unknown",
        "amount": float(amount.group(1).replace("US$", "").replace(",", "")) if amount else 0.0,  # Remove "US$" and commas
        "name": name.group(1) if name else "Unknown",    
    }
    
def process_invoices(input_folder, output_folder):
    results = []
    for file_name in os.listdir(input_folder):
        if file_name.lower().endswith(('.png', '.jpg', '.jpeg')):
            image_path = os.path.join(input_folder, file_name)
            extracted_text = extract_text(image_path)
            
            data = parse_invoice_text(extracted_text)
            
            is_valid, errors = validate_invoice_data(data)
            results.append({**data, "valid": is_valid, "errors": errors})

    # Save results to a CSV file
    df = pd.DataFrame(results)
    output_path = os.path.join(output_folder, "invoice_data.csv")
    df.to_csv(output_path, index=False)
    print(f"Results saved to {output_path}")

if __name__ == "__main__":
    os.makedirs("output", exist_ok=True)
    process_invoices("sample_invoices", "output")