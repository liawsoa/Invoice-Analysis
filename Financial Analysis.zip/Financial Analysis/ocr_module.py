 # @Lia
 # Module for OCR processing
 
from PIL import Image
import pytesseract
 
def extract_text(image_path):
    # Specify the tesseract executable path if needed
    pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
    image = Image.open(image_path)
    return pytesseract.image_to_string(image)

if __name__ == "__main__":
    print(extract_text("sample_invoices/invoice.png"))
    print(extract_text("sample_invoices/invoice1.png"))
    print(extract_text("sample_invoices/invoice2.png"))
    print(extract_text("sample_invoices/invoice3.png"))
    print(extract_text("sample_invoices/invoice4.png"))